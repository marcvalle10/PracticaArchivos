    import java.io.BufferedReader;
    import java.io.FileReader;
    import java.io.IOException;
    import java.util.HashMap;
    import java.util.Map;
    import java.util.regex.Matcher;
    import java.util.regex.Pattern;
    import javax.swing.JFrame;
    import org.jfree.chart.ChartFactory;
    import org.jfree.chart.ChartPanel;
    import org.jfree.chart.JFreeChart;
    import org.jfree.chart.plot.PlotOrientation;
    import org.jfree.data.category.DefaultCategoryDataset;

    public class WordLengthHistogram {

        public static void main(String[] args) {
            String inputFile = "C:/Users/marco/IdeaProjects/PracticaconArchivos/WordLengthHistogram/src/divina_comedia_sp.txt";
            String content = readFile(inputFile);

            Pattern wordPattern = Pattern.compile("\\b[a-zA-ZáéíóúÁÉÍÓÚñÑ]{2,10}\\b");
            Matcher matcher = wordPattern.matcher(content);

            Map<Integer, Integer> histogramData = new HashMap<>();

            while (matcher.find()) {
                String word = matcher.group();
                int length = word.length();
                histogramData.put(length, histogramData.getOrDefault(length, 0) + 1);
            }

            generateHistogram(histogramData);
        }

        private static String readFile(String filePath) {
            StringBuilder content = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    content.append(line).append("\n");
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return content.toString();
        }

        private static void generateHistogram(Map<Integer, Integer> data) {
            DefaultCategoryDataset dataset = new DefaultCategoryDataset();

            for (Map.Entry<Integer, Integer> entry : data.entrySet()) {
                dataset.addValue(entry.getValue(), "Frecuencia", entry.getKey());
            }

            JFreeChart barChart = ChartFactory.createBarChart(
                    "Histograma de Longitud de Palabras",
                    "Longitud de Palabra",
                    "Frecuencia",
                    dataset,
                    PlotOrientation.VERTICAL,
                    true, true, false);

            ChartPanel chartPanel = new ChartPanel(barChart);
            chartPanel.setPreferredSize(new java.awt.Dimension(800, 600));
            JFrame frame = new JFrame("Histograma");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.getContentPane().add(chartPanel);
            frame.pack();
            frame.setVisible(true);
        }
    }
