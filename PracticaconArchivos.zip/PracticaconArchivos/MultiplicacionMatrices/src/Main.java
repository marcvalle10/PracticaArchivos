import java.io.*;

public class Main {
    public static void main(String[] args) {
        try {
            // Abrir los archivos de entrada
            DataInputStream aInput = new DataInputStream(new FileInputStream("C:/Users/marco/IdeaProjects/PracticaconArchivos/MultiplicacionMatrices/src/a.mat"));
            DataInputStream bInput = new DataInputStream(new FileInputStream("C:/Users/marco/IdeaProjects/PracticaconArchivos/MultiplicacionMatrices/src/b.mat"));

            // Leer las dimensiones de las matrices
            int rowsA = aInput.readByte();
            int colsA = aInput.readByte();
            int rowsB = bInput.readByte();
            int colsB = bInput.readByte();

            // Verificar si las matrices son multiplicables
            if (colsA != rowsB) {
                System.out.println("Las matrices no son multiplicables.");
                return;
            }

            // Leer los valores de las matrices
            double[][] matrixA = new double[rowsA][colsA];
            double[][] matrixB = new double[rowsB][colsB];
            for (int i = 0; i < rowsA; i++) {
                for (int j = 0; j < colsA; j++) {
                    matrixA[i][j] = aInput.readDouble();
                }
            }
            for (int i = 0; i < rowsB; i++) {
                for (int j = 0; j < colsB; j++) {
                    matrixB[i][j] = bInput.readDouble();
                }
            }

            // Calcular el producto de las matrices
            double[][] resultMatrix = new double[rowsA][colsB];
            for (int i = 0; i < rowsA; i++) {
                for (int j = 0; j < colsB; j++) {
                    double sum = 0.0;
                    for (int k = 0; k < colsA; k++) {
                        sum += matrixA[i][k] * matrixB[k][j];
                    }
                    resultMatrix[i][j] = sum;
                }
            }

            // Cerrar los archivos de entrada
            aInput.close();
            bInput.close();

            // Escribir el resultado en el archivo de salida c.mat
            DataOutputStream cOutput = new DataOutputStream(new FileOutputStream("C:/Users/marco/IdeaProjects/PracticaconArchivos/MultiplicacionMatrices/src/c.mat"));
            cOutput.writeByte((byte) rowsA);
            cOutput.writeByte((byte) colsB);
            for (int i = 0; i < rowsA; i++) {
                for (int j = 0; j < colsB; j++) {
                    cOutput.writeDouble(resultMatrix[i][j]);
                }
            }

            // Cerrar el archivo de salida
            cOutput.close();

            System.out.println("Producto de matrices calculado y almacenado en c.mat.");

            // Leer y mostrar el contenido del archivo c.mat
            DataInputStream cInput = new DataInputStream(new FileInputStream("C:/Users/marco/IdeaProjects/PracticaconArchivos/MultiplicacionMatrices/src/c.mat"));
            int rowsC = cInput.readByte();
            int colsC = cInput.readByte();
            System.out.println("Contenido del archivo c.mat:");
            for (int i = 0; i < rowsC; i++) {
                for (int j = 0; j < colsC; j++) {
                    double value = cInput.readDouble();
                    System.out.print(value + " ");
                }
                System.out.println();
            }
            cInput.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
